# Topics Covered

* Servers and Clients
* Request/Response cycle
* APIs
* JSON
* `fetch` syntax